// THEME TOGGLE
const themeChange = () => {
	document.querySelector('body').classList.toggle('light');
};

document.querySelector('.theme').addEventListener('click', themeChange);

// AGENT MATCH
const agentMatch = () => {
	let name = prompt('What is your name?');
	let preference = prompt('Do you enjoy playing on a team?');
	let role = prompt(
		'Of the four options, which best describes you: aggressive, strategic, defensive, or supportive?'
	);

	preference = preference.toLowerCase().trim();
	role = role.toLowerCase().trim();

	if (preference === 'yes' && role === 'aggressive') {
		alert(
			`${name}, you'd be a great fit as a Duelist. Aggressive players are needed for entry and protecting teammates to allow them to complete the objective. They are especially important during attack-related tactics.`
		);
		alert(`Try playing Phoenix, Jett, Reyna, Yoru, or Neon!`);
	} else if (preference === 'yes' && role === 'strategic') {
		alert(
			`${name}, you'd be a great fit as an Initiator. It's important that the initiator is levelheaded and strategic in order to help your teammates to complete the objective.`
		);
		alert(`Try playing Sova, Breach, Skye, KAY/O, or Fade!`);
	} else if (preference === 'yes' && role === 'defensive') {
		alert(
			`${name}, you'd be a great fit as a Controller. Controllers are imperative as their abilities regulate match dynamics.`
		);
		alert(`Try playing Brimstone, Viper, Omen, Astra or Harbor!`);
	} else if (preference === 'yes' && role === 'supportive') {
		alert(
			`${name}, you'd be a great fit as a Sentinel. Sentinels are known for their supportive abilities that help their team survive and are especially strong for defensive tactics.`
		);
		alert(`Try playing Killjoy, Cypher, Sage or Chamber!`);
	} else {
		alert(
			"Valorant is a team-based game that requires each team member to play a specific role to complete the overall match objective. It's important that you enjoy playing as a team and also, individually in your role!"
		);
	}
};

const matchHeroBtn = document.querySelector('#hero-match');
matchHeroBtn.addEventListener('click', agentMatch);

const matchFooterBtn = document.querySelector('#footer-match');
matchFooterBtn.addEventListener('click', agentMatch);

// Hover Function to Mobile
document.addEventListener('touchstart', function () {}, true);
